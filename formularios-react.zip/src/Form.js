import React from "react";
import './styles/Form.css';

class Form extends React.Component{

    envioFormulario=event=>{
      
      
       
        event.preventDefault();
        this.props.agregarPersona(
            
            document.getElementById("nombre").value,
            document.getElementById("telefono").value
        );
    
        document.getElementById("nombre").value="";
        document.getElementById("telefono").value="";

    }
    render(){
        return(
            <div>
                <form className="formularios" onSubmit={this.envioFormulario}>
                    <label className="etiquetas">Id:</label> <br />
                    <input className="ingreso" type="number" id="id" placeholder="Ingrese id" required /> <br />

                    <label className="etiquetas">Nombre:</label><br />
                    <input className="ingreso" type="text" id="nombre" placeholder="Ingrese el nombre" required /> <br />
                    <label className="etiquetas">Teléfono:</label><br />
                    <input className="ingreso" type="text" id="telefono" placeholder="Ingrese el teléfono" required /> <br />
                    <button className="botones" type="submit">Enviar</button>
                </form>
            </div>
        )
    }
}

export default Form;