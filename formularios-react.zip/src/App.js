import React,{useState} from 'react';
import './styles/App.css';
import Form from './Form';

function App(){
  const [personas,setPersonas] =useState([
    {id:1,nombre:'Bill Gates',telefono:1234,deuda:true},
    {id:2,nombre:'Elon Musk',telefono:5678,deuda:false},
    {id:3,nombre:'Jordan B. Peterson',telefono:9876,deuda:false},
    {id:4,nombre:'Jack Ma', telefono:4567,deuda:false}
  ]);

  const agregarPersona =(nuevoNombre,telefono)=>{
    const nuevaPersona={id:personas.length + 1, nombre:nuevoNombre, telefono:telefono};
    setPersonas([...personas,nuevaPersona]);
  };

  const eliminarPersona=id=>{
    setPersonas(personas.filter(p=>p.id!==id));
  };

 const actualizarPersonas=id=>{
  setPersonas(personas.map(p=>p.id===id?{...p,deuda:!p.deuda}:p))
 };

 return(
  <div className="App">
    <h1>Bienvenido a mi aplicación</h1>
    <div>
      <h2>
        Datos del visitante
      </h2>
      <Form agregarPersona={agregarPersona} />

    </div>
    <br /> <br />
      <div>
        <h2>Contactos</h2>
        <dl className='lista'>
          {personas.map(i=>(
            <div className='elementos' key={i.id}>
                 <dt>Nombre:{i.nombre}</dt>
                  <dd>ID:{i.id}</dd>
                  <dd>Telefono:{i.telefono}</dd>
                  <dd>Deuda:{i.deuda?'Si':'No'}</dd>
                  <button onClick={()=>eliminarPersona(i.id)} className='boton'>Eliminar</button>
                  {/* Solo actualiza el campo deuda */}
                  <button onClick={()=>actualizarPersonas(i.id)} className='boton'>Modificar</button>
            </div>
           
          ))}
        </dl>
      </div>
  </div>
 )
}

export default App;